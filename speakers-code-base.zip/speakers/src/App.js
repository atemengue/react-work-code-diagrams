/** @format */

import React from 'react';

function App() {
  return (
    <div>
      <h1>React JS WorkShop</h1>
      <h2>Welcome tout a tous</h2>
    </div>
  );
}

export default App;
