/** @format */

import React, { useState } from 'react';
import Footer from './components/Footer';
import Header from './components/Header';
import { data } from './data';
import SpeakerList from './old-components/SpeakerList';

function App() {
  return (
    <div className='ui container'>
      <Header />
      <div className='ui hidden divider' />
      <SpeakerList speakers={data} />
      <div className='ui divider' />
      <Footer />
    </div>
  );
}

export default App;
