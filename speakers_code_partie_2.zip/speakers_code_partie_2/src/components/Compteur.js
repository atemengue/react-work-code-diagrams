/** @format */

import React from 'react';

class Compteur extends React.Component {
  constructor(props) {
    super(props);
    // configuration de la classe
    this.state = { compteur: 0 };
    // this.AjouterUnCompteur = this.AjouterUnCompteur.bind(this);
  }

  AjouterUnCompteur = () => {
    this.setState({
      compteur: this.state.compteur + 1,
    });
  };

  render() {
    return (
      <div>
        <button onClick={this.AjouterUnCompteur} className='ui botton'>
          Ajouter 1
        </button>
        <div>{this.state.compteur}</div>
      </div>
    );
  }
}

export default Compteur;
