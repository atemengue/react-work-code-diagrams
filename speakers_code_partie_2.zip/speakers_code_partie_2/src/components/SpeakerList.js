/** @format */

import React from 'react';
import SpeakerCard from './SpeakerCard';

const SpeakerList = ({ data }) => {
  return (
    <div className='ui four column  stackable grid'>
      {data.map((speaker, index) => {
        return (
          <div key={index} className='four wide column'>
            <SpeakerCard {...speaker} />
          </div>
        );
      })}
    </div>
  );
};

export default SpeakerList;
